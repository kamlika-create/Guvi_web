# Welcome to GUVI - WEB TASK

This web application was created according to the software requirements given in the Problem Statement on [GUVI - Intern](https://www.guvi.in/intern) for web developer role.

## Execution

I developed this application using HTML, SASS/SCSS, JavaScript, BootStrap, AJAX and MySql.
```bash
Do not forget to create a Database. Refer MySql source file. 
```

## Functionalities
1) Login and Signup using local DataBase.
2) Profile page that can be updated.
3) Updated changes are also updated on both the DataBase and JSON.

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.
